import React from "react";

const Analytics = () => {
  return <div>analytics</div>;
};

export default Analytics;
