import React from "react";

const Quotes = () => {
  return <div>quotes</div>;
};

export default Quotes;
